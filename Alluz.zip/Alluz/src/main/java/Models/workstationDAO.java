/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Controller.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author metal
 */
public class workstationDAO {
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public List listar() {
        List<workstation> datos = new ArrayList<>();
        String sql = "select * from Puestos";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                workstation wks = new workstation();
                wks.setId_workStation(rs.getInt(1));
                wks.setWorkName(rs.getString(2));
                wks.setArea_work(rs.getString(3));
                wks.setDate_close(rs.getString(4));
                wks.setRequeridExperience(rs.getString(5));
                wks.setId_Managers(rs.getInt(6));
                datos.add(wks);

            }
        } catch (SQLException e) {
            System.err.print(e.toString());
        }
        return datos;

    }
    
        public int agregar(workstation p) {

        String sql = "insert into Puestos(ID_Puesto, Nombre_Puesto, Area_Puesto, Fecha_Cierre, Experiencia_Requerida, ID_Encargado) values(?,?,?,?,?)";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, p.getId_workStation());
            ps.setString(2, p.getWorkName());
            ps.setString(3, p.getArea_work());
            ps.setString(4, p.getDate_close());
            ps.setString(5, p.getRequeridExperience());
            ps.setInt(6, p.getId_Managers());
            ps.executeUpdate();
        } catch (SQLException e) {

        }
        return 1;

    }

    public int Actulizar(workstation p) {
        String sql = "update Puestos set Nombre_Puesto =?, Area_Puesto=?, Fecha_Cierre=?, Experiencia_Requerida=?, ID_Encargado=? where ID_Puesto=?";
        int r = 0;
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getWorkName());
            ps.setString(2, p.getArea_work());
            ps.setString(3, p.getDate_close());
            ps.setString(4, p.getRequeridExperience());
            ps.setInt(5, p.getId_Managers());
            ps.setInt(6, p.getId_workStation());
            r = ps.executeUpdate();
            if (r == 1) {
                return 1;

            } else {
                return 0;

            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return r;

    }

    public void delete(int id) {
        String sql = "delete from Puestos where ID_Puesto=" + id;
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }

    }

}
