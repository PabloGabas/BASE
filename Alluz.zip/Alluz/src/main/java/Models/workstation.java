/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;



/**
 *
 * @author metal
 */
public class workstation {
    private int id_workStation;
    private String  workName; 
    private String Area_work;
    private String  date_close;
    private String requeridExperience; 
    private int id_Managers;

    public int getId_workStation() {
        return id_workStation;
    }

    public void setId_workStation(int id_workStation) {
        this.id_workStation = id_workStation;
    }

    public String getWorkName() {
        return workName;
    }

    public void setWorkName(String workName) {
        this.workName = workName;
    }

    public String getArea_work() {
        return Area_work;
    }

    public void setArea_work(String Area_work) {
        this.Area_work = Area_work;
    }

    public String getDate_close() {
        return date_close;
    }

    public void setDate_close(String date_close) {
        this.date_close = date_close;
    }

    public String getRequeridExperience() {
        return requeridExperience;
    }

    public void setRequeridExperience(String requeridExperience) {
        this.requeridExperience = requeridExperience;
    }

    public int getId_Managers() {
        return id_Managers;
    }

    public void setId_Managers(int id_Managers) {
        this.id_Managers = id_Managers;
    }

  




    
    
    
    
}
