/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author metal
 */
public class Managers {
    private int id_Manager;
    private String Name;
    private String fisrtName;
    private String lastName;
    private String tel_principal;
    private String tel_secundario;
    private String Correo;
    private String anotherSens;
    private String password;
    private String RRHH_WORK;
    private int id_place;

    public int getId_Manager() {
        return id_Manager;
    }

    public void setId_Manager(int id_Manager) {
        this.id_Manager = id_Manager;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getFisrtName() {
        return fisrtName;
    }

    public void setFisrtName(String fisrtName) {
        this.fisrtName = fisrtName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTel_principal() {
        return tel_principal;
    }

    public void setTel_principal(String tel_principal) {
        this.tel_principal = tel_principal;
    }

    public String getTel_secundario() {
        return tel_secundario;
    }

    public void setTel_secundario(String tel_secundario) {
        this.tel_secundario = tel_secundario;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public String getAnotherSens() {
        return anotherSens;
    }

    public void setAnotherSens(String anotherSens) {
        this.anotherSens = anotherSens;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRRHH_WORK() {
        return RRHH_WORK;
    }

    public void setRRHH_WORK(String RRHH_WORK) {
        this.RRHH_WORK = RRHH_WORK;
    }

    public int getId_place() {
        return id_place;
    }

    public void setId_place(int id_place) {
        this.id_place = id_place;
    }
      
    
    
    
}
