/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Controller.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author metal
 */
public class PersonaDAO {
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public List<Places> listar() {
        List<Places> datos = new ArrayList<>();
        String sql = "SELECT * FROM Lugares";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Places place = new Places();
                place.setId_lugar(rs.getInt(1));
                place.setProvincia(rs.getString(2));
                place.setCanton(rs.getString(3));
                place.setDistrito(rs.getString(4));
                datos.add(place);
            }
        } catch (SQLException e) {
            System.err.println(e.toString());
        }
        return datos;
    }

    public int insertar(Places place) {
        String sql = "INSERT INTO Lugares (ID_Lugar, Provincia, Canton, Distrito) VALUES (?, ?, ?, ?)";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, place.getId_lugar());
            ps.setString(2, place.getProvincia());
            ps.setString(3, place.getCanton());
            ps.setString(4, place.getDistrito());
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e.toString());
            return 0;
        }
    }

    public int actualizar(Places place) {
        String sql = "UPDATE Lugares SET Provincia = ?, Canton = ?, Distrito = ? WHERE ID_Lugar = ?";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, place.getProvincia());
            ps.setString(2, place.getCanton());
            ps.setString(3, place.getDistrito());
            ps.setInt(4, place.getId_lugar());
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e.toString());
            return 0;
        }
    }

    public int eliminar(int id) {
        String sql = "DELETE FROM Lugares WHERE ID_Lugar = ?";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e.toString());
            return 0;
        }
    }
}

