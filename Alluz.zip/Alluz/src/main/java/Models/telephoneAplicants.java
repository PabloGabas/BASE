/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author metal
 */
public class telephoneAplicants {
    private int ID_postulante;
    private int telefono;

    public int getID_postulante() {
        return ID_postulante;
    }

    public void setID_postulante(int ID_postulante) {
        this.ID_postulante = ID_postulante;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
    
    
}
