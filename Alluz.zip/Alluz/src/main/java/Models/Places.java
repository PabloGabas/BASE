/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author metal
 */
public class Places {
    private int id_lugar;
    private String Provincia;
    private String Canton;
    private String Distrito;

    public Places() {
    }

    public Places(int id_lugar, String Provincia, String Canton, String Distrito) {
        this.id_lugar = id_lugar;
        this.Provincia = Provincia;
        this.Canton = Canton;
        this.Distrito = Distrito;
    }

    
    public int getId_lugar() {
        return id_lugar;
    }

    public void setId_lugar(int id_lugar) {
        this.id_lugar = id_lugar;
    }

    public String getProvincia() {
        return Provincia;
    }

    public void setProvincia(String Provincia) {
        this.Provincia = Provincia;
    }

    public String getCanton() {
        return Canton;
    }

    public void setCanton(String Canton) {
        this.Canton = Canton;
    }

    public String getDistrito() {
        return Distrito;
    }

    public void setDistrito(String Distrito) {
        this.Distrito = Distrito;
    }

   
    
}
