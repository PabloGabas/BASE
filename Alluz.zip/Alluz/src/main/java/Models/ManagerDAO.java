/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Controller.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author metal
 */
public class ManagerDAO {
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    
    
    
  public List listar() {
        List<Managers> datos = new ArrayList<>();
        String sql = "select * from Encargados";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Managers mg = new Managers();
                mg.setId_Manager(rs.getInt(1));
                mg.setName(rs.getString(2));
                mg.setFisrtName(rs.getString(3));
                mg.setLastName(rs.getString(4));
                mg.setTel_principal(rs.getString(5));
                mg.setTel_secundario(rs.getString(6));
                mg.setCorreo(rs.getString(7));
                mg.setAnotherSens(rs.getString(8));
                mg.setPassword(rs.getString(9));
                mg.setRRHH_WORK(rs.getString(10));
                mg.setId_place(rs.getInt(11));
                datos.add(mg);

            }
        } catch (SQLException e) {
            System.err.print(e.toString());
        }
        return datos;

    }


public int insertar(Managers mg) {
    String sql = "INSERT INTO Encargados (ID_Encargado, Nombre, Apellido_1, Apellido_2, Tel_Principal, Tel_Secundario, Correo_Electronico, Otras_Senas, Contrasena, Puesto_RRHH, ID_Lugar) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    try {
        con = conectar.getConnection();
        ps = con.prepareStatement(sql);
        ps.setInt(1, mg.getId_Manager());
        ps.setString(2, mg.getName());
        ps.setString(3, mg.getFisrtName());
        ps.setString(4, mg.getLastName());
        ps.setString(5, mg.getTel_principal());
        ps.setString(6, mg.getTel_secundario());
        ps.setString(7, mg.getCorreo());
        ps.setString(8, mg.getAnotherSens());
        ps.setString(9, mg.getPassword());
        ps.setString(10, mg.getRRHH_WORK());
        ps.setInt(11, mg.getId_place());
        return ps.executeUpdate();
    } catch (SQLException e) {
        System.err.println(e.toString());
        return 0;
    }
}

public int actualizar(Managers mg) {
    String sql = "UPDATE Encargados SET Nombre=?, Apellido_1=?, Apellido_2=?, Tel_Principal=?, Tel_Secundario=?, Correo_Electronico=?, Otras_Senas=?, Contrasena=?, Puesto_RRHH=?, ID_Lugar=? WHERE ID_Encargado=?";
    try {
        con = conectar.getConnection();
        ps = con.prepareStatement(sql);
        ps.setString(1, mg.getName());
        ps.setString(2, mg.getFisrtName());
        ps.setString(3, mg.getLastName());
        ps.setString(4, mg.getTel_principal());
        ps.setString(5, mg.getTel_secundario());
        ps.setString(6, mg.getCorreo());
        ps.setString(7, mg.getAnotherSens());
        ps.setString(8, mg.getPassword());
        ps.setString(9, mg.getRRHH_WORK());
        ps.setInt(10, mg.getId_place());
        ps.setInt(11, mg.getId_Manager());
        return ps.executeUpdate();
    } catch (SQLException e) {
        System.err.println(e.toString());
        return 0;
    }
}

public int eliminar(int id) {
    String sql = "DELETE FROM Encargados WHERE ID_Encargado=?";
    try {
        con = conectar.getConnection();
        ps = con.prepareStatement(sql);
        ps.setInt(1, id);
        return ps.executeUpdate();
    } catch (SQLException e) {
        System.err.println(e.toString());
        return 0;
    }
}





  
}
