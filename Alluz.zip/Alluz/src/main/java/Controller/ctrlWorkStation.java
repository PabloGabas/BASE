/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Models.PersonaDAO;
import Models.Places;
import Models.workstation;
import Models.workstationDAO;
import Views.frmPlaces;
import Views.frmWorkStation;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author metal
 */
public class ctrlWorkStation implements ActionListener {

    workstationDAO dao = new workstationDAO();
    workstation p = new workstation();
    frmWorkStation vista = new frmWorkStation();
    DefaultTableModel modelo = new DefaultTableModel();
   

    public ctrlWorkStation(frmWorkStation v) {
        this.vista = v;
        this.vista.btnListar.addActionListener(this);
        
        this.vista.btnEditar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        
        

        Listar(vista.tabla);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnListar) {
            limpiarTabla();
            Listar(vista.tabla);
        }
        if (e.getSource() == vista.btnGuardar) {
            aregar();
            limpiarTabla();
            Listar(vista.tabla);
        }
        if (e.getSource() == vista.btnEditar) {
    int fila = vista.tabla.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(vista, "Debe seleccionar una fila");
    } else {
        int id = Integer.parseInt(vista.tabla.getValueAt(fila, 0).toString());
        
       String dateString = vista.tabla.getValueAt(fila, 1).toString();
        String nombreTrabajo = vista.tabla.getValueAt(fila, 2).toString();
        String AreaTrabajo = vista.tabla.getValueAt(fila, 3).toString();
        String experiencia = vista.tabla.getValueAt(fila, 4).toString();
        int id_Manager = Integer.parseInt(vista.tabla.getValueAt(fila, 5).toString());

        vista.txtID.setText(String.valueOf(id));
        vista.txtname.setText(dateString);
        vista.txtAreaTrabajo.setText(nombreTrabajo);
        vista.txtCierraFecha.setText(AreaTrabajo);
        vista.txtExperienciaRequerida.setText(experiencia);
        vista.txtEncargadoID.setText(String.valueOf(id_Manager));
    }
}

        if (e.getSource() == vista.btnActualizar) {
            Actualizar();
            limpiarTabla();
            Listar(vista.tabla);

        }
        if (e.getSource() == vista.btnEliminar) {
            delete();
            limpiarTabla();
            Listar(vista.tabla);
        }
    }

    public void delete() {
        int fila = vista.tabla.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar un usuario");
        } else {
            int id = Integer.parseInt((String) vista.tabla.getValueAt(fila, 0).toString());
            dao.delete(id);
            JOptionPane.showMessageDialog(vista, "Usuario eliminado");

        }

    }

    void limpiarTabla() {
        for (int i = 0; i < vista.tabla.getRowCount(); i++) {
            modelo.removeRow(i);
            i = i - 1;
        }

    }

    public void Actualizar() {
    int id = Integer.parseInt(vista.txtID.getText());

       
        String Nombre = vista.txtname.getText();
        String Area = vista.txtAreaTrabajo.getText();
        String date_close = vista.txtCierraFecha.getText();
        String Experencia = vista.txtExperienciaRequerida.getText();
        int id_encagado = Integer.parseInt(vista.txtEncargadoID.getText());

        p.setId_workStation(id);
        p.setWorkName(Nombre);
        p.setArea_work(Area);
        p.setDate_close(date_close);
        p.setRequeridExperience(Experencia);
        p.setId_Managers(id_encagado);
        int r = dao.agregar(p);
        if (r == 1) {
            JOptionPane.showMessageDialog(vista, "Usuario Agregado");
        } else {
            JOptionPane.showMessageDialog(vista, "Error");

        }
}


    public void aregar() {
        int id = Integer.parseInt(vista.txtID.getText());

       
        String Nombre = vista.txtAreaTrabajo.getText();
        String Area = vista.txtCierraFecha.getText();
        String date_close = vista.txtname.getText();
        String Experencia = vista.txtExperienciaRequerida.getText();
        int id_encagado = Integer.parseInt(vista.txtEncargadoID.getText());

        p.setId_workStation(id);
        p.setWorkName(Nombre);
        p.setArea_work(Area);
        p.setDate_close(date_close);
        p.setRequeridExperience(Experencia);
        p.setId_Managers(id_encagado);
        int r = dao.agregar(p);
        if (r == 1) {
            JOptionPane.showMessageDialog(vista, "Usuario Agregado");
        } else {
            JOptionPane.showMessageDialog(vista, "Error");

        }
    }

    public void Listar(JTable tabla) {
        modelo = (DefaultTableModel) tabla.getModel();
        List<workstation> Lista = dao.listar();
        Object[] object = new Object[6];
        for (int i = 0; i < Lista.size(); i++) {
            object[0] = Lista.get(i).getId_workStation();
            object[1] = Lista.get(i).getWorkName();
            object[2] = Lista.get(i).getArea_work();
            object[3] = Lista.get(i).getDate_close();
            object[4] = Lista.get(i).getRequeridExperience();
            object[5] = Lista.get(i).getId_Managers();

            modelo.addRow(object);
        }
        vista.tabla.setModel(modelo);
    }
}
