/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
public class CtrlInsertPuestos {

    Conexion conectar = new Conexion();
    Connection con;

    public void insertarDatos(javax.swing.JTextField txtID, javax.swing.JTextField txtName, 
                              javax.swing.JTextField txtAreaTrabajo, javax.swing.JTextField txtCierraFecha,
                              javax.swing.JTextField txtExperienciaRequerida, javax.swing.JTextField txtEncargadoID) {
        // Obtener los datos desde los campos de texto
        try {
            int id = Integer.parseInt(txtID.getText());
            String name = txtName.getText();
            String areaTrabajo = txtAreaTrabajo.getText();
            String fechaCierre = txtCierraFecha.getText(); // Fecha como String
            String experienciaRequerida = txtExperienciaRequerida.getText();
            int idEncargado = Integer.parseInt(txtEncargadoID.getText());

            // Validaciones opcionales (asegúrate de no permitir campos vacíos o inválidos)
            if (name.isEmpty() || areaTrabajo.isEmpty() || experienciaRequerida.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
                return;
            }

            // Preparar consulta SQL
            String sql = "INSERT INTO Puestos (ID_Puesto, Nombre_Puesto, Area_Puesto, Fecha_Cierre, Experiencia_Requerida, ID_Encargado) "
                       + "VALUES (?, ?, ?, ?, ?, ?)";
            con = conectar.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            // Configurar parámetros
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, areaTrabajo);
            ps.setString(4, fechaCierre); // Insertar la fecha como String
            ps.setString(5, experienciaRequerida);
            ps.setInt(6, idEncargado);

            // Ejecutar consulta
            int rowsInserted = ps.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Registro insertado con éxito.");
            } else {
                JOptionPane.showMessageDialog(null, "Error al insertar el registro.");
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ID y ID de Encargado deben ser números válidos.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en la base de datos: " + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error inesperado: " + e.getMessage());
        }
    }
    
    
    public void actualizarDatos(javax.swing.JTextField txtID, javax.swing.JTextField txtName, 
                            javax.swing.JTextField txtAreaTrabajo, javax.swing.JTextField txtCierraFecha,
                            javax.swing.JTextField txtExperienciaRequerida, javax.swing.JTextField txtEncargadoID) {
    try {
        // Obtener los datos desde los campos de texto
        int id = Integer.parseInt(txtID.getText());
        String name = txtName.getText();
        String areaTrabajo = txtAreaTrabajo.getText();
        String fechaCierre = txtCierraFecha.getText(); // Fecha como String
        String experienciaRequerida = txtExperienciaRequerida.getText();
        int idEncargado = Integer.parseInt(txtEncargadoID.getText());

        // Validaciones opcionales
        if (name.isEmpty() || areaTrabajo.isEmpty() || experienciaRequerida.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            return;
        }

        // Preparar consulta SQL para actualizar
        String sql = "UPDATE Puestos SET Nombre_Puesto = ?, Area_Puesto = ?, Fecha_Cierre = ?, "
                   + "Experiencia_Requerida = ?, ID_Encargado = ? WHERE ID_Puesto = ?";
        con = conectar.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);

        // Configurar parámetros
        ps.setString(1, name);
        ps.setString(2, areaTrabajo);
        ps.setString(3, fechaCierre); // Actualizar la fecha como String
        ps.setString(4, experienciaRequerida);
        ps.setInt(5, idEncargado);
        ps.setInt(6, id);

        // Ejecutar consulta
        int rowsUpdated = ps.executeUpdate();
        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(null, "Registro actualizado con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró un registro con el ID especificado.");
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "ID y ID de Encargado deben ser números válidos.");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error en la base de datos: " + e.getMessage());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error inesperado: " + e.getMessage());
    }
}
    public void eliminarDatos(javax.swing.JTextField txtID) {
    try {
        // Obtener el ID desde el campo de texto
        int id = Integer.parseInt(txtID.getText());

        // Confirmación antes de eliminar
        int confirm = JOptionPane.showConfirmDialog(null, "¿Está seguro de eliminar este registro?", 
                                                    "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return; // Salir si el usuario selecciona "No"
        }

        // Consulta SQL para eliminar
        String sql = "DELETE FROM Puestos WHERE ID_Puesto = ?";
        con = conectar.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);

        // Configurar el parámetro
        ps.setInt(1, id);

        // Ejecutar consulta
        int rowsDeleted = ps.executeUpdate();
        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró un registro con el ID especificado.");
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "El ID debe ser un número válido.");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error en la base de datos: " + e.getMessage());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error inesperado: " + e.getMessage());
    }
}
    
    
    
    
    
}
