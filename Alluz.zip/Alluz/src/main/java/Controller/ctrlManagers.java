/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Models.ManagerDAO;
import Models.Managers;
import Models.PersonaDAO;
import Models.Places;
import Views.frmManagers;
import Views.frmPlaces;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author metal
 */
public class ctrlManagers implements ActionListener{
 
    ManagerDAO dao = new ManagerDAO();
    Managers manager = new Managers();
    frmManagers   vista = new frmManagers();
    DefaultTableModel modelo = new DefaultTableModel();
    
    
    
    public ctrlManagers(frmManagers vista) {
        this.vista = vista;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnListar.addActionListener(this);
        this.vista.btnEditar.addActionListener(this);
        listar(vista.tabla);
    }

   public void listar(JTable tabla) {
        modelo = (DefaultTableModel) tabla.getModel();
        List<Managers> Lista = dao.listar();
        Object[] object = new Object[11];
        for (int i = 0; i < Lista.size(); i++) {
            object[0] = Lista.get(i).getId_Manager();
            object[1] = Lista.get(i).getName();
            object[2] = Lista.get(i).getFisrtName();
            object[3] = Lista.get(i).getLastName();
            object[4] = Lista.get(i).getTel_principal();
            object[5] = Lista.get(i).getTel_secundario();
            object[6] = Lista.get(i).getCorreo();
            object[7] = Lista.get(i).getAnotherSens();
            object[8] = Lista.get(i).getPassword();
            object[9] = Lista.get(i).getRRHH_WORK();
            object[10] = Lista.get(i).getId_place();
            modelo.addRow(object);
        }
        vista.tabla.setModel(modelo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       if (e.getSource() == vista.btnListar) {
            listar(vista.tabla);
        }
       if (e.getSource() == vista.btnGuardar) {
            agregar();
            limpiarTabla();
            listar(vista.tabla);
        } else if (e.getSource() == vista.btnActualizar) {
            actualizar();
            limpiarTabla();
            listar(vista.tabla);
        } else if (e.getSource() == vista.btnEliminar) {
            eliminar();
            limpiarTabla();
            listar(vista.tabla);
        } else if (e.getSource() == vista.btnListar) {
            limpiarTabla(); 
            listar(vista.tabla);
        }
       if (e.getSource() == vista.btnEditar) {
    int fila = vista.tabla.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(vista, "Debe seleccionar una fila");
    } else {
        // Obtener los valores de la fila seleccionada
        int id = Integer.parseInt(vista.tabla.getValueAt(fila, 0).toString());
        String nombre = vista.tabla.getValueAt(fila, 1).toString();
        String primerApellido = vista.tabla.getValueAt(fila, 2).toString();
        String segundoApellido = vista.tabla.getValueAt(fila, 3).toString();
        String telPrincipal = vista.tabla.getValueAt(fila, 4).toString();
        String telSecundario = vista.tabla.getValueAt(fila, 5).toString();
        String correo = vista.tabla.getValueAt(fila, 6).toString();
        String otrasSenas = vista.tabla.getValueAt(fila, 7).toString();
        String contrasena = vista.tabla.getValueAt(fila, 8).toString();
        String puestoRRHH = vista.tabla.getValueAt(fila, 9).toString();
        int idLugarTrabajo = Integer.parseInt(vista.tabla.getValueAt(fila, 10).toString());

        // Asignar los valores a los campos de texto
        vista.txtID.setText(String.valueOf(id));
        vista.txtNombre.setText(nombre);
        vista.txtPrimer_Ape.setText(primerApellido);
        vista.txtSegundoApellido.setText(segundoApellido);
        vista.Telefono_Principal.setText(telPrincipal);
        vista.Telefono_Secundario.setText(telSecundario);
        vista.txtCorreo.setText(correo);
        vista.OtrasSenas.setText(otrasSenas);
        vista.txtContra.setText(contrasena);
        vista.Puesto_Recursos.setText(puestoRRHH);
        vista.Id_Combo.setText(String.valueOf(idLugarTrabajo));
    }
}
    }
    
   private void agregar() {
        manager.setId_Manager(Integer.parseInt(vista.txtID.getText()));
        manager.setName(vista.txtNombre.getText());
        manager.setFisrtName(vista.txtPrimer_Ape.getText());
        manager.setLastName(vista.txtSegundoApellido.getText());
        manager.setTel_principal(vista.Telefono_Principal.getText());
        manager.setTel_secundario(vista.Telefono_Secundario.getText());
        manager.setCorreo(vista.txtCorreo.getText());
        manager.setAnotherSens(vista.OtrasSenas.getText());
        manager.setPassword(vista.txtContra.getText());
        manager.setRRHH_WORK(vista.Puesto_Recursos.getText());
        manager.setId_place(Integer.parseInt(vista.Id_Combo.getText()));

        int r = dao.insertar(manager);
        if (r == 1) {
            JOptionPane.showMessageDialog(vista, "Registro agregado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(vista, "Error al agregar el registro.");
        }
    }

    private void actualizar() {
        manager.setId_Manager(Integer.parseInt(vista.txtID.getText()));
        manager.setName(vista.txtNombre.getText());
        manager.setFisrtName(vista.txtPrimer_Ape.getText());
        manager.setLastName(vista.txtSegundoApellido.getText());
        manager.setTel_principal(vista.Telefono_Principal.getText());
        manager.setTel_secundario(vista.Telefono_Secundario.getText());
        manager.setCorreo(vista.txtCorreo.getText());
        manager.setAnotherSens(vista.OtrasSenas.getText());
        manager.setPassword(vista.txtContra.getText());
        manager.setRRHH_WORK(vista.Puesto_Recursos.getText());
        manager.setId_place(Integer.parseInt(vista.Id_Combo.getText()));

        int r = dao.actualizar(manager);
        if (r == 1) {
            JOptionPane.showMessageDialog(vista, "Registro actualizado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(vista, "Error al actualizar el registro.");
        }
    }

    private void eliminar() {
        int fila = vista.tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar una fila.");
        } else {
            int id = Integer.parseInt(vista.tabla.getValueAt(fila, 0).toString());
            int r = dao.eliminar(id);
            if (r == 1) {
                JOptionPane.showMessageDialog(vista, "Registro eliminado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "Error al eliminar el registro.");
            }
        }
    }
    
    private void limpiarTabla() {
    modelo.setRowCount(0); 
}
}
