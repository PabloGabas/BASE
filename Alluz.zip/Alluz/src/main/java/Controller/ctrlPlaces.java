/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Models.PersonaDAO;
import Models.Places;
import Views.frmPlaces;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 
 */
public class ctrlPlaces implements ActionListener {
    PersonaDAO dao = new PersonaDAO();
    Places place = new Places();
    frmPlaces vista = new frmPlaces();
    DefaultTableModel modelo = new DefaultTableModel();

    public ctrlPlaces(frmPlaces vista) {
        this.vista = vista;
        this.vista.btnListar.addActionListener(this);
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnEditar.addActionListener(this);
        listar(vista.tabla);
    }

    public void listar(JTable tabla) {
        modelo = (DefaultTableModel) tabla.getModel();
        List<Places> lista = dao.listar();
        Object[] object = new Object[4];
        for (Places place : lista) {
            object[0] = place.getId_lugar();
            object[1] = place.getProvincia();
            object[2] = place.getCanton();
            object[3] = place.getDistrito();
            modelo.addRow(object);
        }
        tabla.setModel(modelo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnListar) {
            limpiarTabla();
            listar(vista.tabla);
        } else if (e.getSource() == vista.btnGuardar) {
            agregar();
            limpiarTabla();
            listar(vista.tabla);
        } else if (e.getSource() == vista.btnActualizar) {
            actualizar();
            limpiarTabla();
            listar(vista.tabla);
        } else if (e.getSource() == vista.btnEliminar) {
            eliminar();
            limpiarTabla();
            listar(vista.tabla);
        } else if (e.getSource() == vista.btnEditar) {
            editar();
        }
    }

    private void agregar() {
        place.setId_lugar(Integer.parseInt(vista.txtID.getText()));
        place.setProvincia(vista.txtProvincia.getText());
        place.setCanton(vista.txtCanton.getText());
        place.setDistrito(vista.txtDistrito.getText());

        int r = dao.insertar(place);
        if (r == 1) {
            JOptionPane.showMessageDialog(vista, "Registro agregado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(vista, "Error al agregar el registro.");
        }
    }

    private void actualizar() {
        place.setId_lugar(Integer.parseInt(vista.txtID.getText()));
        place.setProvincia(vista.txtProvincia.getText());
        place.setCanton(vista.txtCanton.getText());
        place.setDistrito(vista.txtDistrito.getText());

        int r = dao.actualizar(place);
        if (r == 1) {
            JOptionPane.showMessageDialog(vista, "Registro actualizado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(vista, "Error al actualizar el registro.");
        }
    }

    private void eliminar() {
        int fila = vista.tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar una fila.");
        } else {
            int id = Integer.parseInt(vista.tabla.getValueAt(fila, 0).toString());
            int r = dao.eliminar(id);
            if (r == 1) {
                JOptionPane.showMessageDialog(vista, "Registro eliminado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "Error al eliminar el registro.");
            }
        }
    }

    private void editar() {
        int fila = vista.tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar una fila.");
        } else {
            vista.txtID.setText(vista.tabla.getValueAt(fila, 0).toString());
            vista.txtProvincia.setText(vista.tabla.getValueAt(fila, 1).toString());
            vista.txtCanton.setText(vista.tabla.getValueAt(fila, 2).toString());
            vista.txtDistrito.setText(vista.tabla.getValueAt(fila, 3).toString());
        }
    }

    private void limpiarTabla() {
        modelo.setRowCount(0);
    }
}

