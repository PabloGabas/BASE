/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Extras;

import Controller.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author metal
 */
public class RellenarCombos {
   public void RellenarComboBox(JComboBox<String> combo) {
        String sql = "SELECT ID_Lugar, Provincia, Canton, Distrito FROM Lugares";
        Statement st;
        Conexion con = new Conexion();
        Connection conexion = con.getConnection();

        try {
            st = conexion.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                // Concatenar los valores de las columnas en un solo String
                String item = rs.getInt("ID_Lugar") + " - " + 
                              rs.getString("Provincia") + ", " + 
                              rs.getString("Canton") + ", " + 
                              rs.getString("Distrito");
                combo.addItem(item); // Agregar la concatenación al JComboBox
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        } finally {
            try {
                if (conexion != null) conexion.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.toString());
            }
        }
    }
   
   
    public void RellenarComboBoxPuestoTrabajo(JComboBox<String> combo) {
        String sql = "SELECT ID_Encargado, Nombre, Apellido_1,Puesto_RRHH FROM Encargados";
        Statement st;
        Conexion con = new Conexion();
        Connection conexion = con.getConnection();

        try {
            st = conexion.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                // Concatenar los valores de las columnas en un solo String
                String item = rs.getInt("ID_Encargado") + " - " + 
                              rs.getString("Nombre") + ", " + 
                              rs.getString("Apellido_1") + ", " + 
                              rs.getString("Puesto_RRHH");
                combo.addItem(item); // Agregar la concatenación al JComboBox
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        } finally {
            try {
                if (conexion != null) conexion.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.toString());
            }
        }
    }
}
